UIKit
-----

We currently use UIKit only for the markdown editor. We might expand this to
other things, perhaps.

Once it's working properly, we might want to integrate it into our Grunt/Bower
build setup: https://github.com/uikit/uikit

The compressed codemirror was built at http://codemirror.net/doc/compress.html
with the following options:

   Version: 5.6

   CodeMirror Library:
   - codemirror.js
   Modes:
   - gfm.js
   - htmlembedded.js
   - htmlmixed.js
   - markdown.js
   - xml.js
   Add-ons:
   - active-line.js
   - colorize.js
   - comment.js
   - markdown-fold.js
   - mark-selection.js
   - matchtags.js
   - overlay.js
   - trailingspace.js
   - xml-fold.js



